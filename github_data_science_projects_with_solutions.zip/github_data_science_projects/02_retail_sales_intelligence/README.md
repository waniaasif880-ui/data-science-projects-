# Retail Sales Intelligence Dashboard

## Objective
Analyze a year of retail transactions to find revenue and profit trends, product performance, and sales-channel differences.

## Files
- `data/retail_sales.csv` — synthetic sample retail data.
- `solution.py` — complete analysis, summary tables, KPI calculations, and charts.
- `outputs/` — CSV summaries and PNG charts created when the script runs.

## Tools
Python, pandas, Matplotlib.

## Run
```bash
pip install -r requirements.txt
python solution.py
```

## Key outputs
- Monthly revenue, profit, units, and order counts.
- Product revenue/profit ranking.
- Channel revenue/profit comparison.
- Total revenue, total profit, and profit margin.

## Important limitation
The dataset is synthetic and is intended for portfolio practice. Do not describe its results as actual business results.
