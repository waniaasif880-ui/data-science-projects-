"""Retail Sales Intelligence - analysis and charts."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
df = pd.read_csv(ROOT / "data" / "retail_sales.csv", parse_dates=["order_date"])
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

print("Shape:", df.shape)
print("\\nMissing values:\\n", df.isna().sum())
print("\\nSummary statistics:\\n", df[["units_sold","unit_price","unit_cost","revenue","profit"]].describe().round(2))

df["month"] = df["order_date"].dt.to_period("M").astype(str)
monthly = df.groupby("month", as_index=False).agg(
    revenue=("revenue","sum"), profit=("profit","sum"),
    units_sold=("units_sold","sum"), orders=("order_date","count")
)
monthly.to_csv(OUT / "monthly_kpis.csv", index=False)
print("\\nMonthly KPIs:\\n", monthly.to_string(index=False))

products = df.groupby("product", as_index=False).agg(
    revenue=("revenue","sum"), profit=("profit","sum"), units_sold=("units_sold","sum")
).sort_values("revenue", ascending=False)
products.to_csv(OUT / "product_performance.csv", index=False)
print("\\nProduct performance:\\n", products.to_string(index=False))

channels = df.groupby("sales_channel", as_index=False).agg(
    revenue=("revenue","sum"), profit=("profit","sum")
).sort_values("revenue", ascending=False)
channels.to_csv(OUT / "channel_performance.csv", index=False)
print("\\nChannel performance:\\n", channels.to_string(index=False))

plt.figure(figsize=(10,5))
plt.plot(monthly["month"], monthly["revenue"], marker="o")
plt.xticks(rotation=45, ha="right")
plt.title("Monthly Revenue"); plt.xlabel("Month"); plt.ylabel("Revenue")
plt.tight_layout(); plt.savefig(OUT/"monthly_revenue.png", dpi=150); plt.close()

plt.figure(figsize=(9,5))
plt.bar(products["product"], products["profit"])
plt.xticks(rotation=25, ha="right")
plt.title("Profit by Product"); plt.xlabel("Product"); plt.ylabel("Profit")
plt.tight_layout(); plt.savefig(OUT/"profit_by_product.png", dpi=150); plt.close()

plt.figure(figsize=(8,5))
plt.bar(channels["sales_channel"], channels["revenue"])
plt.title("Revenue by Sales Channel"); plt.xlabel("Channel"); plt.ylabel("Revenue")
plt.tight_layout(); plt.savefig(OUT/"revenue_by_channel.png", dpi=150); plt.close()

total_revenue = df["revenue"].sum()
total_profit = df["profit"].sum()
profit_margin = (total_profit / total_revenue * 100) if total_revenue else 0
print(f"\\nTotal revenue: {total_revenue:,.2f}")
print(f"Total profit: {total_profit:,.2f}")
print(f"Profit margin: {profit_margin:.2f}%")
