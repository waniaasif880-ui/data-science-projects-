# Academic Performance Forecasting System

## Objective
Use student study habits and previous academic indicators to classify performance as **Low**, **Medium**, or **High**.

## Files
- `data/student_performance.csv` — synthetic practice dataset (500 rows).
- `solution.py` — complete Python solution: inspection, preprocessing, Random Forest, cross-validation, evaluation, plot, and sample prediction.
- `outputs/` — generated evaluation plot after running the script.

## Tools
Python, pandas, Matplotlib, scikit-learn.

## Run
```bash
pip install -r requirements.txt
python solution.py
```

## Method
1. Inspect the data and check missing values.
2. Separate input features from the target label.
3. One-hot encode the categorical feature.
4. Split into training and test sets.
5. Train a Random Forest classifier.
6. Report test accuracy, precision/recall/F1, and 5-fold cross-validation.

## Important limitation
The included dataset is **synthetic**, generated for demonstration. Results are not evidence of real-world predictive performance and should not be used to make decisions about actual students.
