"""Academic Performance Forecasting - complete beginner-friendly solution."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "student_performance.csv"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

# 1. Load and inspect data
df = pd.read_csv(DATA)
print("First five rows:\\n", df.head())
print("\\nDataset shape:", df.shape)
print("\\nMissing values:\\n", df.isnull().sum())
print("\\nClass distribution:\\n", df["performance_level"].value_counts())

# 2. Define features (X) and target (y)
X = df.drop(columns="performance_level")
y = df["performance_level"]
numeric_features = ["study_hours_per_day", "attendance_percent",
                    "previous_score", "assignment_average"]
categorical_features = ["internet_access"]

preprocess = ColumnTransformer([
    ("numeric", "passthrough", numeric_features),
    ("categorical", OneHotEncoder(handle_unknown="ignore"), categorical_features)
])
model = Pipeline([
    ("preprocess", preprocess),
    ("classifier", RandomForestClassifier(n_estimators=200, random_state=42,
                                          class_weight="balanced"))
])

# 3. Split data so the test set is not used for training
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
model.fit(X_train, y_train)
predictions = model.predict(X_test)

# 4. Evaluate
print("\\nTest accuracy:", round(accuracy_score(y_test, predictions), 3))
print("\\nClassification report:\\n", classification_report(y_test, predictions, zero_division=0))
cv_scores = cross_val_score(model, X, y, cv=5, scoring="accuracy")
print("5-fold cross-validation scores:", cv_scores.round(3))
print("Mean CV accuracy:", round(cv_scores.mean(), 3))

# 5. Save confusion matrix
ConfusionMatrixDisplay.from_predictions(y_test, predictions)
plt.title("Academic Performance - Confusion Matrix")
plt.tight_layout()
plt.savefig(OUT / "confusion_matrix.png", dpi=150)
plt.close()

# 6. Predict for a new example
new_student = pd.DataFrame([{
    "study_hours_per_day": 4.0, "attendance_percent": 85.0,
    "previous_score": 72.0, "assignment_average": 78.0,
    "internet_access": "Yes"
}])
print("\\nExample prediction:", model.predict(new_student)[0])
print("Note: this is a learning demo using synthetic data, not a validated student assessment.")
