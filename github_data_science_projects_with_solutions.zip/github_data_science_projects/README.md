# Data Science Portfolio Projects

This repository contains three beginner-friendly Python projects with source code, sample data, and instructions.

## Projects
1. **Academic Performance Forecasting** — classification with scikit-learn.
2. **Retail Sales Intelligence** — descriptive analytics, KPIs, and charts.
3. **Automated Data Processing Pipeline** — data cleaning, validation, and Excel output.

## Getting started
Open a project folder and follow its README. Each project has its own `requirements.txt`.

## Data note
The included datasets are synthetic and created for learning/demo purposes. Results are not real institutional or business claims.
