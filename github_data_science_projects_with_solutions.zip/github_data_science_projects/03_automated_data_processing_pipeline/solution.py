"""A small repeatable data cleaning pipeline with validation and Excel output."""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "data" / "raw_customer_orders.csv"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

def clean_orders(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for col in ["customer_name", "email", "city"]:
        df[col] = df[col].astype("string").str.strip()
    df["customer_name"] = df["customer_name"].str.title()
    df["email"] = df["email"].str.lower()
    df["city"] = df["city"].str.title()
    df["order_amount"] = pd.to_numeric(df["order_amount"], errors="coerce")
    df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")
    df = df.drop_duplicates(subset=["customer_id", "email", "order_date", "order_amount"])
    invalid_mask = df["order_amount"].isna() | df["order_date"].isna()
    df.loc[invalid_mask].to_csv(OUT / "records_needing_review.csv", index=False)
    cleaned = df.loc[~invalid_mask].copy()
    cleaned["order_amount"] = cleaned["order_amount"].round(2)
    cleaned = cleaned.sort_values(["order_date", "customer_id"])
    return cleaned

def main():
    raw = pd.read_csv(INPUT)
    print("Raw rows:", len(raw))
    print("Raw missing values:\\n", raw.isna().sum())
    cleaned = clean_orders(raw)
    cleaned.to_csv(OUT / "cleaned_orders.csv", index=False)
    quality = pd.DataFrame({
        "metric": ["raw_rows", "cleaned_rows", "rows_removed_or_flagged"],
        "value": [len(raw), len(cleaned), len(raw) - len(cleaned)]
    })
    with pd.ExcelWriter(OUT / "processed_orders.xlsx", engine="openpyxl") as writer:
        cleaned.to_excel(writer, sheet_name="Cleaned Data", index=False)
        quality.to_excel(writer, sheet_name="Quality Summary", index=False)
    print("\\nCleaned rows:", len(cleaned))
    print("Saved:", OUT / "cleaned_orders.csv")
    print("Saved:", OUT / "processed_orders.xlsx")
    print("Review invalid records in:", OUT / "records_needing_review.csv")

if __name__ == "__main__":
    main()
