# Automated Data Processing Pipeline

## Objective
Turn messy customer-order data into a consistent, analysis-ready dataset through repeatable cleaning steps.

## Files
- `data/raw_customer_orders.csv` — deliberately messy practice input with duplicates, inconsistent capitalization, and invalid values.
- `solution.py` — complete pipeline for cleaning, validation, duplicate removal, and Excel export.
- `outputs/` — generated when the solution runs.

## Tools
Python, pandas, openpyxl.

## Run
```bash
pip install -r requirements.txt
python solution.py
```

## Cleaning steps
1. Trim whitespace and standardize names, emails, and cities.
2. Convert amounts to numeric values and dates to datetime values.
3. Remove duplicate records using a defined key.
4. Export invalid rows separately for review.
5. Save clean CSV and Excel outputs with a quality summary.

## Important limitation
This is a demonstration pipeline and uses synthetic customer-order data, not real client records.
