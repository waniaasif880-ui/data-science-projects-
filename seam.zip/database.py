"""
database.py — Seam data layer
SQLite-backed, fully offline, no external dependencies beyond stdlib.
"""

import sqlite3
import secrets
import string
from datetime import datetime, timedelta
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "seam.db")


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


# ── Schema ──────────────────────────────────────────────────────────────────

def init_db():
    with get_conn() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS listings (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            title       TEXT    NOT NULL,
            category    TEXT    NOT NULL,
            condition   TEXT    NOT NULL,
            location    TEXT    NOT NULL,
            description TEXT,
            giver_name  TEXT    NOT NULL,
            status      TEXT    NOT NULL DEFAULT 'available',
            created_at  TEXT    NOT NULL,
            claimed_at  TEXT,
            completed_at TEXT
        );

        CREATE TABLE IF NOT EXISTS claims (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            listing_id   INTEGER NOT NULL REFERENCES listings(id),
            claimer_name TEXT    NOT NULL,
            pickup_code  TEXT    NOT NULL UNIQUE,
            status       TEXT    NOT NULL DEFAULT 'pending',
            created_at   TEXT    NOT NULL,
            confirmed_at TEXT
        );
        """)


# ── Helpers ──────────────────────────────────────────────────────────────────

def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _gen_code():
    """6-char alphanumeric pickup code using secrets module."""
    alphabet = string.ascii_uppercase + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(6))


# ── Listings ─────────────────────────────────────────────────────────────────

def add_listing(title, category, condition, location, description, giver_name):
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO listings
               (title, category, condition, location, description, giver_name, status, created_at)
               VALUES (?,?,?,?,?,?,'available',?)""",
            (title, category, condition, location, description, giver_name, _now())
        )
    return True


def get_listings(status=None, category=None):
    sql = "SELECT * FROM listings WHERE 1=1"
    params = []
    if status:
        sql += " AND status=?"
        params.append(status)
    if category and category != "All":
        sql += " AND category=?"
        params.append(category)
    sql += " ORDER BY created_at DESC"
    with get_conn() as conn:
        return [dict(r) for r in conn.execute(sql, params).fetchall()]


def get_listing(listing_id):
    with get_conn() as conn:
        r = conn.execute("SELECT * FROM listings WHERE id=?", (listing_id,)).fetchone()
        return dict(r) if r else None


def delete_listing(listing_id):
    with get_conn() as conn:
        conn.execute("DELETE FROM claims WHERE listing_id=?", (listing_id,))
        conn.execute("DELETE FROM listings WHERE id=?", (listing_id,))


# ── Claims ────────────────────────────────────────────────────────────────────

def claim_listing(listing_id, claimer_name):
    """Returns pickup_code string, or None if already claimed."""
    with get_conn() as conn:
        listing = conn.execute(
            "SELECT status FROM listings WHERE id=?", (listing_id,)
        ).fetchone()
        if not listing or listing["status"] != "available":
            return None
        code = _gen_code()
        conn.execute(
            """INSERT INTO claims (listing_id, claimer_name, pickup_code, status, created_at)
               VALUES (?,?,?,'pending',?)""",
            (listing_id, claimer_name, code, _now())
        )
        conn.execute(
            "UPDATE listings SET status='claimed', claimed_at=? WHERE id=?",
            (_now(), listing_id)
        )
        return code


def confirm_exchange(pickup_code):
    """Marks claim + listing as completed. Returns True on success."""
    with get_conn() as conn:
        claim = conn.execute(
            "SELECT * FROM claims WHERE pickup_code=? AND status='pending'",
            (pickup_code,)
        ).fetchone()
        if not claim:
            return False
        now = _now()
        conn.execute(
            "UPDATE claims SET status='completed', confirmed_at=? WHERE id=?",
            (now, claim["id"])
        )
        conn.execute(
            "UPDATE listings SET status='completed', completed_at=? WHERE id=?",
            (now, claim["listing_id"])
        )
        return True


def cancel_claim(listing_id):
    """Frees a claimed listing back to available."""
    with get_conn() as conn:
        conn.execute(
            "UPDATE claims SET status='cancelled' WHERE listing_id=? AND status='pending'",
            (listing_id,)
        )
        conn.execute(
            "UPDATE listings SET status='available', claimed_at=NULL WHERE id=?",
            (listing_id,)
        )


def get_claim_for_listing(listing_id):
    with get_conn() as conn:
        r = conn.execute(
            "SELECT * FROM claims WHERE listing_id=? ORDER BY created_at DESC LIMIT 1",
            (listing_id,)
        ).fetchone()
        return dict(r) if r else None


# ── Admin / Analytics ─────────────────────────────────────────────────────────

def get_stats():
    with get_conn() as conn:
        total    = conn.execute("SELECT COUNT(*) FROM listings").fetchone()[0]
        available= conn.execute("SELECT COUNT(*) FROM listings WHERE status='available'").fetchone()[0]
        claimed  = conn.execute("SELECT COUNT(*) FROM listings WHERE status='claimed'").fetchone()[0]
        completed= conn.execute("SELECT COUNT(*) FROM listings WHERE status='completed'").fetchone()[0]

        by_cat = conn.execute("""
            SELECT category,
                   COUNT(*) as total,
                   SUM(CASE WHEN status='available' THEN 1 ELSE 0 END) as available,
                   SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) as completed
            FROM listings GROUP BY category ORDER BY total DESC
        """).fetchall()

        velocity = conn.execute("""
            SELECT l.category,
                   AVG(
                     (julianday(l.completed_at) - julianday(l.created_at))
                   ) as avg_days
            FROM listings l
            WHERE l.status='completed' AND l.completed_at IS NOT NULL
            GROUP BY l.category
        """).fetchall()

    return {
        "total": total,
        "available": available,
        "claimed": claimed,
        "completed": completed,
        "by_category": [dict(r) for r in by_cat],
        "velocity": [dict(r) for r in velocity],
    }


# ── Seed Data ─────────────────────────────────────────────────────────────────

def seed_sample_data():
    """Insert realistic demo listings so the app isn't empty on first run."""
    with get_conn() as conn:
        count = conn.execute("SELECT COUNT(*) FROM listings").fetchone()[0]
        if count > 0:
            return  # already seeded

    samples = [
        # (title, category, condition, location, description, giver_name, status, days_ago, days_to_complete)
        ("Lab coat, size M", "Clothing", "Good", "Block C Lab Locker", "Worn twice for first-year lab sessions. Whoever needs it — come get it.", "Ayesha R.", "completed", 30, 3),
        ("Formal blazer, navy", "Clothing", "Good", "Girls Hostel Gate", "For presentations. Just needs a wash, otherwise perfect.", "Sana M.", "available", 5, None),
        ("Winter jacket — large", "Clothing", "Fair", "Main Gate Reception", "Too big for me now. Someone will need this in November.", "Omar K.", "completed", 45, 7),
        ("Dupatta collection (3)", "Clothing", "Good", "Room 204, Girls Hostel", "Formal dupattas from events. All folded, good condition.", "Hira T.", "available", 2, None),
        ("Calculus by Stewart, 8th ed.", "Books & Notes", "Good", "Library Help Desk", "Done with it and it's not cheap. Pick up before finals.", "Bilal A.", "completed", 20, 2),
        ("Linear Algebra notes — full semester", "Books & Notes", "Good", "CS Department Pigeonholes", "Handwritten, very organised. Complete coverage.", "Zara N.", "available", 8, None),
        ("Past papers — 4 years CS", "Books & Notes", "Good", "Study Room 3, Library", "Past paper collection going back four years. Take them.", "Usman F.", "claimed", 10, None),
        ("Thermodynamics textbook", "Books & Notes", "Fair", "Engineering Block B", "Some highlighting but all pages intact.", "Ali H.", "available", 3, None),
        ("Type-C hub, 6-port", "Electronics & Gear", "Good", "IT Help Desk", "Works fine. Bought a new one that fits my bag better.", "Mariam S.", "completed", 15, 1),
        ("Soldering iron — body only", "Electronics & Gear", "Fair", "Electronics Lab Technician", "Needs a new tip but the body is completely usable.", "Hassan R.", "available", 6, None),
        ("3x HDMI cables", "Electronics & Gear", "Good", "Dorm Block A, Room 110", "Anyone in dorms will need one of these.", "Fatima K.", "completed", 25, 4),
        ("Old Android phone — reset", "Electronics & Gear", "Good", "Main Cafeteria Info Desk", "Factory reset, good screen, working perfectly.", "Tariq B.", "available", 1, None),
        ("Graphics calculator — Casio", "Electronics & Gear", "Good", "Maths Dept Reception", "Passed my finals. Someone else's turn.", "Nadia Z.", "available", 4, None),
        ("Desk lamp — white", "Open", "Good", "Hostel Block B Exit", "Moving out of hostel. Grab it before Sunday.", "Raza M.", "completed", 12, 2),
        ("Architecture drawing set", "Open", "Good", "Architecture Studio", "Full set from first year. Never touched again after.", "Layla A.", "available", 7, None),
        ("Stationery box — full", "Open", "Good", "Student Affairs Office", "Rulers, compasses, highlighters, protractors. All there.", "Imran S.", "available", 2, None),
        ("Desk organiser — wooden", "Open", "Good", "Library Entrance Shelf", "Clearing out my room. Solid wood, fits nicely on a desk.", "Amna F.", "claimed", 9, None),
        ("Prayer mat — travel size", "Open", "Good", "Masjid Entrance", "Compact, clean. Upgrading to a larger one.", "Yusuf D.", "available", 1, None),
    ]

    now = datetime.now()
    with get_conn() as conn:
        for s in samples:
            title, cat, cond, loc, desc, giver, status, days_ago, days_complete = s
            created = (now - timedelta(days=days_ago)).strftime("%Y-%m-%d %H:%M:%S")
            claimed_at = None
            completed_at = None
            if status in ("claimed", "completed"):
                claimed_at = (now - timedelta(days=max(days_ago - 1, 0))).strftime("%Y-%m-%d %H:%M:%S")
            if status == "completed" and days_complete:
                completed_at = (now - timedelta(days=max(days_ago - days_complete, 0))).strftime("%Y-%m-%d %H:%M:%S")

            conn.execute(
                """INSERT INTO listings
                   (title, category, condition, location, description, giver_name,
                    status, created_at, claimed_at, completed_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (title, cat, cond, loc, desc, giver, status, created, claimed_at, completed_at)
            )

        # Add a pending claim for the "claimed" items
        claimed_rows = conn.execute(
            "SELECT id FROM listings WHERE status='claimed'"
        ).fetchall()
        for row in claimed_rows:
            code = _gen_code()
            conn.execute(
                """INSERT INTO claims (listing_id, claimer_name, pickup_code, status, created_at)
                   VALUES (?,?,?,'pending',?)""",
                (row["id"], "Demo Claimer", code, _now())
            )
