"""
app.py — Seam: Campus Goods Exchange
Main Tkinter application. Run with: python app.py
"""

import tkinter as tk
from tkinter import messagebox, simpledialog
import database as db
import theme as T
import charts


# ═══════════════════════════════════════════════════════════════════════════════
#  Listing Card (used in Browse view)
# ═══════════════════════════════════════════════════════════════════════════════

class ListingCard(tk.Frame):
    def __init__(self, parent, listing, on_claim, on_delete, bg=T.CREAM):
        super().__init__(parent, bg=bg,
                         highlightthickness=1,
                         highlightbackground=T.PETAL)
        self.listing = listing
        self._build(on_claim, on_delete, bg)

    def _build(self, on_claim, on_delete, bg):
        # Top row: title + status badge
        top = tk.Frame(self, bg=bg)
        top.pack(fill="x", padx=14, pady=(12, 4))

        tk.Label(top, text=self.listing["title"],
                 font=T.F(12, "normal", "italic"),
                 fg=T.INK, bg=bg, anchor="w").pack(side="left")

        T.status_badge(top, self.listing["status"], bg=bg).pack(side="right", padx=(8, 0))

        # Meta row: category · condition · location
        meta_parts = [
            self.listing["category"],
            self.listing["condition"],
            f'📍 {self.listing["location"]}',
        ]
        tk.Label(self, text="  ·  ".join(meta_parts),
                 font=T.Fsans(9), fg=T.STONE, bg=bg, anchor="w"
                 ).pack(fill="x", padx=14, pady=(0, 4))

        # Description (if any)
        if self.listing.get("description"):
            tk.Label(self, text=self.listing["description"],
                     font=T.Fsans(10), fg=T.STONE, bg=bg,
                     wraplength=480, justify="left", anchor="w"
                     ).pack(fill="x", padx=14, pady=(0, 6))

        # Footer: giver name + date + actions
        foot = tk.Frame(self, bg=bg)
        foot.pack(fill="x", padx=14, pady=(4, 12))

        date_str = self.listing["created_at"][:10]
        tk.Label(foot, text=f"From {self.listing['giver_name']}  ·  {date_str}",
                 font=T.Fsans(9), fg=T.STONE, bg=bg).pack(side="left")

        if self.listing["status"] == "available":
            T.btn(foot, "Claim", command=lambda: on_claim(self.listing),
                  primary=True, small=True).pack(side="right", padx=(6, 0))

        # Always show delete for admin convenience (no auth on this button — admin panel has it)
        T.btn(foot, "Remove", command=lambda: on_delete(self.listing["id"]),
              primary=False, small=True).pack(side="right")


# ═══════════════════════════════════════════════════════════════════════════════
#  Browse / Post View  (student-facing)
# ═══════════════════════════════════════════════════════════════════════════════

class BrowseView(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=T.PAPER)
        self._filter_cat = tk.StringVar(value="All")
        self._search_var = tk.StringVar()
        self._build()
        self._load()

    def _build(self):
        # ── Toolbar ──────────────────────────────────────────────────────────
        toolbar = tk.Frame(self, bg=T.WARM)
        toolbar.pack(fill="x")

        inner = tk.Frame(toolbar, bg=T.WARM)
        inner.pack(padx=20, pady=10, fill="x")

        T.heading(inner, "Browse Listings", 14, bg=T.WARM).pack(side="left")

        T.btn(inner, "+ Post Item", command=self._open_post_form,
              primary=True, small=True).pack(side="right", padx=(8, 0))
        T.btn(inner, "↻ Refresh", command=self._load,
              primary=False, small=True).pack(side="right")

        # Filter bar
        fbar = tk.Frame(self, bg=T.PAPER)
        fbar.pack(fill="x", padx=20, pady=(10, 4))

        T.label(fbar, "Category:", size=10, bg=T.PAPER).pack(side="left", padx=(0, 6))
        cats = ["All"] + T.CATEGORIES
        T.combo(fbar, cats, textvariable=self._filter_cat, width=18
                ).pack(side="left")
        self._filter_cat.trace_add("write", lambda *_: self._load())

        T.label(fbar, "  Search:", size=10, bg=T.PAPER).pack(side="left", padx=(12, 6))
        se = T.entry(fbar, textvariable=self._search_var, width=24)
        se.pack(side="left")
        self._search_var.trace_add("write", lambda *_: self._load())

        T.divider(self, pady=4)

        # ── Scrollable listing area ───────────────────────────────────────────
        outer, self._inner, _ = T.scrollable_frame(self)
        outer.pack(fill="both", expand=True, padx=0, pady=0)

    def _load(self):
        for w in self._inner.winfo_children():
            w.destroy()

        cat = self._filter_cat.get()
        listings = db.get_listings(category=cat if cat != "All" else None)

        q = self._search_var.get().lower()
        if q:
            listings = [l for l in listings
                        if q in l["title"].lower()
                        or q in (l["description"] or "").lower()
                        or q in l["giver_name"].lower()]

        if not listings:
            tk.Label(self._inner,
                     text="No listings found. Be the first to post something!",
                     font=T.Fsans(11), fg=T.STONE, bg=T.PAPER
                     ).pack(pady=40)
            return

        for listing in listings:
            card = ListingCard(self._inner, listing,
                               on_claim=self._handle_claim,
                               on_delete=self._handle_delete)
            card.pack(fill="x", padx=20, pady=6)

    def _open_post_form(self):
        PostDialog(self, on_success=self._load)

    def _handle_claim(self, listing):
        ClaimDialog(self, listing, on_success=self._load)

    def _handle_delete(self, listing_id):
        if messagebox.askyesno("Remove Listing",
                               "Remove this listing permanently?",
                               parent=self):
            db.delete_listing(listing_id)
            self._load()


# ═══════════════════════════════════════════════════════════════════════════════
#  Post Dialog
# ═══════════════════════════════════════════════════════════════════════════════

class PostDialog(tk.Toplevel):
    def __init__(self, parent, on_success=None):
        super().__init__(parent)
        self.title("Post an Item")
        self.configure(bg=T.PAPER)
        self.resizable(False, False)
        self._on_success = on_success
        self._build()
        self.grab_set()
        self.focus_force()

    def _build(self):
        pad = dict(padx=24, pady=6, sticky="w")

        T.heading(self, "Give an item away", 15, italic=True,
                  bg=T.PAPER).grid(row=0, column=0, columnspan=2,
                                   padx=24, pady=(20, 10), sticky="w")

        fields = [
            ("Item title *", "title"),
            ("Your name *",  "giver"),
        ]
        self._vars = {}
        for i, (lbl, key) in enumerate(fields, start=1):
            T.label(self, lbl, size=10, bg=T.PAPER).grid(row=i, column=0, **pad)
            v = tk.StringVar()
            self._vars[key] = v
            T.entry(self, textvariable=v).grid(row=i, column=1, **pad)

        # Category
        T.label(self, "Category *", size=10, bg=T.PAPER).grid(row=3, column=0, **pad)
        self._cat = tk.StringVar(value=T.CATEGORIES[0])
        T.combo(self, T.CATEGORIES, textvariable=self._cat).grid(row=3, column=1, **pad)

        # Condition
        T.label(self, "Condition *", size=10, bg=T.PAPER).grid(row=4, column=0, **pad)
        self._cond = tk.StringVar(value=T.CONDITIONS[1])
        T.combo(self, T.CONDITIONS, textvariable=self._cond).grid(row=4, column=1, **pad)

        # Location
        T.label(self, "Pickup location *", size=10, bg=T.PAPER).grid(row=5, column=0, **pad)
        self._loc = tk.StringVar(value=T.LOCATIONS[0])
        T.combo(self, T.LOCATIONS, textvariable=self._loc, width=30).grid(row=5, column=1, **pad)

        # Description
        T.label(self, "Description", size=10, bg=T.PAPER).grid(row=6, column=0,
                                                                padx=24, pady=6, sticky="nw")
        self._desc = T.textarea(self)
        self._desc.grid(row=6, column=1, padx=24, pady=6, sticky="w")

        T.divider(self, pady=0).grid(row=7, column=0, columnspan=2,
                                     sticky="ew", padx=24, pady=10)

        btnf = tk.Frame(self, bg=T.PAPER)
        btnf.grid(row=8, column=0, columnspan=2, padx=24, pady=(0, 20), sticky="e")
        T.btn(btnf, "Cancel", command=self.destroy, primary=False, small=True).pack(side="left", padx=6)
        T.btn(btnf, "Post Item", command=self._submit, primary=True, small=True).pack(side="left")

    def _submit(self):
        title  = self._vars["title"].get().strip()
        giver  = self._vars["giver"].get().strip()
        cat    = self._cat.get()
        cond   = self._cond.get()
        loc    = self._loc.get()
        desc   = self._desc.get("1.0", "end").strip()

        if not title or not giver:
            messagebox.showwarning("Missing fields",
                                   "Please fill in Title and Your Name.",
                                   parent=self)
            return

        db.add_listing(title, cat, cond, loc, desc, giver)
        if self._on_success:
            self._on_success()
        self.destroy()


# ═══════════════════════════════════════════════════════════════════════════════
#  Claim Dialog
# ═══════════════════════════════════════════════════════════════════════════════

class ClaimDialog(tk.Toplevel):
    def __init__(self, parent, listing, on_success=None):
        super().__init__(parent)
        self.title("Claim Item")
        self.configure(bg=T.PAPER)
        self.resizable(False, False)
        self._listing    = listing
        self._on_success = on_success
        self._build()
        self.grab_set()
        self.focus_force()

    def _build(self):
        pad = dict(padx=28, pady=8)

        T.heading(self, "Claim this item", 15, italic=True,
                  bg=T.PAPER).pack(**pad, anchor="w", pady=(20, 4))

        info = tk.Frame(self, bg=T.WARM,
                        highlightthickness=1,
                        highlightbackground=T.PETAL)
        info.pack(fill="x", padx=28, pady=8)

        tk.Label(info, text=self._listing["title"],
                 font=T.F(12, "normal", "italic"),
                 fg=T.INK, bg=T.WARM).pack(anchor="w", padx=12, pady=(10, 2))
        tk.Label(info, text=f'Pickup: {self._listing["location"]}',
                 font=T.Fsans(10), fg=T.STONE, bg=T.WARM).pack(anchor="w", padx=12, pady=(0, 10))

        T.label(self, "Your name *", size=10, bg=T.PAPER).pack(**pad, anchor="w", pady=(8, 0))
        self._name = tk.StringVar()
        T.entry(self, textvariable=self._name, width=30).pack(padx=28, pady=(0, 8), anchor="w")

        T.body(self,
               "Once you claim this item, you'll receive a 6-character pickup code. "
               "Show it to the giver when you collect.",
               bg=T.PAPER, wrap=340
               ).pack(padx=28, pady=4, anchor="w")

        T.divider(self, pady=0).pack(fill="x", padx=28, pady=10)

        btnf = tk.Frame(self, bg=T.PAPER)
        btnf.pack(padx=28, pady=(0, 20), anchor="e")
        T.btn(btnf, "Cancel",  command=self.destroy,  primary=False, small=True).pack(side="left", padx=6)
        T.btn(btnf, "Claim →", command=self._submit, primary=True,  small=True).pack(side="left")

    def _submit(self):
        name = self._name.get().strip()
        if not name:
            messagebox.showwarning("Name required",
                                   "Please enter your name to claim this item.",
                                   parent=self)
            return

        code = db.claim_listing(self._listing["id"], name)
        if code is None:
            messagebox.showinfo("Already claimed",
                                "Sorry — someone else just claimed this item.",
                                parent=self)
            self.destroy()
            if self._on_success:
                self._on_success()
            return

        self.destroy()
        PickupCodeWindow(self.master, code, self._listing, on_close=self._on_success)


# ═══════════════════════════════════════════════════════════════════════════════
#  Pickup Code Window
# ═══════════════════════════════════════════════════════════════════════════════

class PickupCodeWindow(tk.Toplevel):
    def __init__(self, parent, code, listing, on_close=None):
        super().__init__(parent)
        self.title("Your Pickup Code")
        self.configure(bg=T.INK2)
        self.resizable(False, False)
        self._code     = code
        self._listing  = listing
        self._on_close = on_close
        self._build()
        self.grab_set()
        self.focus_force()
        self.protocol("WM_DELETE_WINDOW", self._close)

    def _build(self):
        tk.Label(self, text="Your pickup code",
                 font=T.Fsans(10), fg=T.STONE, bg=T.INK2
                 ).pack(padx=40, pady=(28, 8))

        tk.Label(self, text=self._code,
                 font=("Courier", 46, "bold"),
                 fg=T.WHITE, bg=T.INK2,
                 letterSpacing=8
                 ).pack(padx=40, pady=8)

        tk.Label(self,
                 text=(f'Show this code to the giver of\n'
                       f'"{self._listing["title"]}"\n'
                       f'at {self._listing["location"]}'),
                 font=T.Fsans(11), fg=T.STONE, bg=T.INK2,
                 justify="center"
                 ).pack(padx=40, pady=(8, 28))

        T.btn(self, "Done — I've collected it",
              command=self._confirm, primary=True
              ).pack(padx=40, pady=(0, 12))

        T.btn(self, "I haven't collected it yet",
              command=self._close, primary=False
              ).pack(padx=40, pady=(0, 28))

    def _confirm(self):
        db.confirm_exchange(self._code)
        messagebox.showinfo("Exchange complete",
                            "Great — this item has been marked as collected. "
                            "Thanks for keeping Seam moving.",
                            parent=self)
        self._close()

    def _close(self):
        if self._on_close:
            self._on_close()
        self.destroy()


# ═══════════════════════════════════════════════════════════════════════════════
#  Admin Panel
# ═══════════════════════════════════════════════════════════════════════════════

class AdminView(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=T.PAPER)
        self._authed = False
        self._build()

    def _build(self):
        # ── Login gate ────────────────────────────────────────────────────────
        self._login_frame = tk.Frame(self, bg=T.PAPER)
        self._login_frame.pack(expand=True)

        T.heading(self._login_frame, "Admin Access", 16, italic=True,
                  bg=T.PAPER).pack(pady=(40, 8))
        T.body(self._login_frame, "Enter the admin password to continue.",
               bg=T.PAPER).pack(pady=(0, 16))

        self._pw_var = tk.StringVar()
        pw_entry = T.entry(self._login_frame, textvariable=self._pw_var, width=22, show="•")
        pw_entry.pack(pady=4)
        pw_entry.bind("<Return>", lambda e: self._auth())

        T.btn(self._login_frame, "Unlock", command=self._auth, primary=True
              ).pack(pady=12)

        # ── Dashboard (hidden until auth) ─────────────────────────────────────
        self._dash_frame = tk.Frame(self, bg=T.PAPER)

    def _auth(self):
        if self._pw_var.get() == T.ADMIN_PASSWORD:
            self._login_frame.pack_forget()
            self._dash_frame.pack(fill="both", expand=True)
            self._build_dashboard()
            self._authed = True
        else:
            messagebox.showerror("Incorrect password",
                                 "That password is incorrect.",
                                 parent=self)

    def _build_dashboard(self):
        stats = db.get_stats()

        # ── Toolbar ───────────────────────────────────────────────────────────
        toolbar = tk.Frame(self._dash_frame, bg=T.INK2)
        toolbar.pack(fill="x")
        inner = tk.Frame(toolbar, bg=T.INK2)
        inner.pack(padx=20, pady=12, fill="x")

        T.heading(inner, "Admin Dashboard", 14, color=T.WHITE,
                  bg=T.INK2).pack(side="left")
        T.btn(inner, "↻ Refresh", command=self._refresh,
              primary=False, small=True).pack(side="right")

        # ── Stat summary ──────────────────────────────────────────────────────
        sf = tk.Frame(self._dash_frame, bg=T.WARM)
        sf.pack(fill="x")
        sfi = tk.Frame(sf, bg=T.WARM)
        sfi.pack(padx=20, pady=12, fill="x")

        for label_text, val in [
            ("Total listed",  stats["total"]),
            ("Available",     stats["available"]),
            ("Claimed",       stats["claimed"]),
            ("Completed",     stats["completed"]),
        ]:
            col = tk.Frame(sfi, bg=T.WARM)
            col.pack(side="left", padx=20)
            tk.Label(col, text=str(val),
                     font=T.F(28, "normal", "italic"),
                     fg=T.ROSE, bg=T.WARM).pack()
            tk.Label(col, text=label_text,
                     font=T.Fsans(9), fg=T.STONE, bg=T.WARM).pack()

        T.divider(self._dash_frame, pady=0)

        # ── Scrollable body ───────────────────────────────────────────────────
        outer, body_frame, _ = T.scrollable_frame(self._dash_frame)
        outer.pack(fill="both", expand=True)

        # Charts
        charts_row = tk.Frame(body_frame, bg=T.PAPER)
        charts_row.pack(fill="x", padx=20, pady=16)

        left_chart  = tk.Frame(charts_row, bg=T.CREAM,
                                highlightthickness=1,
                                highlightbackground=T.PETAL)
        right_chart = tk.Frame(charts_row, bg=T.CREAM,
                                highlightthickness=1,
                                highlightbackground=T.PETAL)
        left_chart.pack(side="left", fill="both", expand=True, padx=(0, 8))
        right_chart.pack(side="left", fill="both", expand=True)

        cat_canvas = charts.make_category_chart(stats, left_chart)
        if cat_canvas:
            cat_canvas.get_tk_widget().pack(fill="both", expand=True, padx=8, pady=8)
        else:
            T.body(left_chart, "No data yet.", bg=T.CREAM).pack(pady=20)

        vel_canvas = charts.make_velocity_chart(stats, right_chart)
        if vel_canvas:
            vel_canvas.get_tk_widget().pack(fill="both", expand=True, padx=8, pady=8)
        else:
            T.body(right_chart, "No completed exchanges yet.", bg=T.CREAM).pack(pady=20)

        T.divider(body_frame, pady=8)

        # ── Listings table ────────────────────────────────────────────────────
        T.heading(body_frame, "All Listings", 13, italic=True,
                  bg=T.PAPER).pack(anchor="w", padx=20, pady=(8, 4))

        self._admin_list_frame = tk.Frame(body_frame, bg=T.PAPER)
        self._admin_list_frame.pack(fill="x", padx=20, pady=4)
        self._populate_listing_table(stats)

    def _populate_listing_table(self, stats=None):
        for w in self._admin_list_frame.winfo_children():
            w.destroy()

        listings = db.get_listings()
        if not listings:
            T.body(self._admin_list_frame, "No listings yet.", bg=T.PAPER).pack(pady=8)
            return

        headers = ["ID", "Title", "Category", "Condition", "Status", "Giver", "Date", "Action"]
        widths   = [3,    28,      14,          10,          11,        14,      10,      8]

        hrow = tk.Frame(self._admin_list_frame, bg=T.WARM)
        hrow.pack(fill="x", pady=(0, 2))
        for h, w in zip(headers, widths):
            tk.Label(hrow, text=h, font=T.Fsans(9, "bold"),
                     fg=T.STONE, bg=T.WARM, width=w, anchor="w"
                     ).pack(side="left", padx=4, pady=4)

        for lst in listings:
            row_bg = T.CREAM if listings.index(lst) % 2 == 0 else T.PAPER
            row = tk.Frame(self._admin_list_frame, bg=row_bg)
            row.pack(fill="x")

            vals = [
                str(lst["id"]),
                lst["title"][:26] + "…" if len(lst["title"]) > 26 else lst["title"],
                lst["category"],
                lst["condition"],
                lst["status"],
                lst["giver_name"],
                lst["created_at"][:10],
            ]
            for val, w in zip(vals, widths):
                tk.Label(row, text=val, font=T.Fsans(9),
                         fg=T.INK, bg=row_bg, width=w, anchor="w"
                         ).pack(side="left", padx=4, pady=3)

            # Action buttons
            af = tk.Frame(row, bg=row_bg)
            af.pack(side="left", padx=4)

            if lst["status"] == "claimed":
                claim = db.get_claim_for_listing(lst["id"])
                if claim:
                    T.btn(af, f'Code: {claim["pickup_code"]}',
                          command=lambda c=claim["pickup_code"]: messagebox.showinfo(
                              "Pickup Code", f"Code: {c}", parent=self),
                          primary=False, small=True).pack(side="left", padx=2)
                    T.btn(af, "Cancel",
                          command=lambda lid=lst["id"]: self._cancel_claim(lid),
                          primary=False, small=True).pack(side="left", padx=2)

            T.btn(af, "Delete",
                  command=lambda lid=lst["id"]: self._delete(lid),
                  primary=False, small=True).pack(side="left", padx=2)

    def _cancel_claim(self, listing_id):
        if messagebox.askyesno("Cancel Claim",
                               "Free this listing back to available?",
                               parent=self):
            db.cancel_claim(listing_id)
            self._refresh()

    def _delete(self, listing_id):
        if messagebox.askyesno("Delete Listing",
                               "Permanently delete this listing?",
                               parent=self):
            db.delete_listing(listing_id)
            self._refresh()

    def _refresh(self):
        for w in self._dash_frame.winfo_children():
            w.destroy()
        self._build_dashboard()


# ═══════════════════════════════════════════════════════════════════════════════
#  Confirm Exchange View  (standalone tab for code entry)
# ═══════════════════════════════════════════════════════════════════════════════

class ConfirmView(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=T.PAPER)
        self._build()

    def _build(self):
        centre = tk.Frame(self, bg=T.PAPER)
        centre.place(relx=0.5, rely=0.42, anchor="center")

        T.heading(centre, "Confirm a handoff", 18, italic=True,
                  bg=T.PAPER).pack(pady=(0, 6))
        T.body(centre,
               "Enter the 6-character pickup code to mark an exchange as complete.",
               bg=T.PAPER, wrap=340).pack(pady=(0, 20))

        self._code_var = tk.StringVar()
        code_entry = T.entry(centre, textvariable=self._code_var, width=12)
        code_entry.config(font=("Courier", 24, "bold"), justify="center")
        code_entry.pack(pady=4)
        code_entry.bind("<Return>", lambda e: self._confirm())

        T.btn(centre, "Confirm Exchange", command=self._confirm, primary=True
              ).pack(pady=12)

        self._status_lbl = tk.Label(centre, text="", font=T.Fsans(11),
                                    fg=T.ROSE, bg=T.PAPER)
        self._status_lbl.pack()

    def _confirm(self):
        code = self._code_var.get().strip().upper()
        if not code:
            self._status_lbl.config(text="Please enter a pickup code.")
            return
        ok = db.confirm_exchange(code)
        if ok:
            self._status_lbl.config(
                text=f"✓ Exchange confirmed for code {code}.",
                fg="#2d6a4f"
            )
            self._code_var.set("")
        else:
            self._status_lbl.config(
                text=f"Code '{code}' not found or already used.",
                fg=T.ROSE
            )


# ═══════════════════════════════════════════════════════════════════════════════
#  Root Application Window
# ═══════════════════════════════════════════════════════════════════════════════

class SeamApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Seam — Campus Goods Exchange")
        self.geometry("900x680")
        self.minsize(760, 540)
        self.configure(bg=T.INK2)
        self._build()

    def _build(self):
        # ── Header bar ────────────────────────────────────────────────────────
        header = tk.Frame(self, bg=T.INK2, height=52)
        header.pack(fill="x")
        header.pack_propagate(False)

        brand = tk.Frame(header, bg=T.INK2)
        brand.pack(side="left", padx=20)
        tk.Label(brand, text="Se", font=T.F(18, "normal", "italic"),
                 fg=T.ROSE2, bg=T.INK2).pack(side="left")
        tk.Label(brand, text="am", font=T.F(18, "normal", "italic"),
                 fg=T.WHITE, bg=T.INK2).pack(side="left")
        tk.Label(brand, text="  Campus Goods Exchange",
                 font=T.Fsans(10), fg=T.STONE, bg=T.INK2).pack(side="left")

        # Tab buttons
        tab_frame = tk.Frame(header, bg=T.INK2)
        tab_frame.pack(side="right", padx=12)

        self._tabs = {}
        self._tab_btns = {}
        for name in ("Browse", "Confirm", "Admin"):
            b = tk.Button(tab_frame, text=name,
                          font=T.Fsans(10),
                          fg=T.STONE, bg=T.INK2,
                          activeforeground=T.WHITE,
                          activebackground=T.INK2,
                          relief="flat", bd=0,
                          padx=14, pady=14,
                          cursor="hand2",
                          command=lambda n=name: self._switch(n))
            b.pack(side="left")
            self._tab_btns[name] = b

        T.divider(self, bg=T.ROSE, height=2, pady=0)

        # ── Tab content ───────────────────────────────────────────────────────
        self._content = tk.Frame(self, bg=T.PAPER)
        self._content.pack(fill="both", expand=True)

        self._tabs["Browse"]  = BrowseView(self._content)
        self._tabs["Confirm"] = ConfirmView(self._content)
        self._tabs["Admin"]   = AdminView(self._content)

        self._switch("Browse")

    def _switch(self, name):
        for n, frame in self._tabs.items():
            frame.pack_forget()
            self._tab_btns[n].config(fg=T.STONE,
                                      font=T.Fsans(10))
        self._tabs[name].pack(fill="both", expand=True)
        self._tab_btns[name].config(fg=T.WHITE,
                                     font=T.Fsans(10, "bold"))


# ═══════════════════════════════════════════════════════════════════════════════
#  Entry point
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    db.init_db()
    db.seed_sample_data()
    app = SeamApp()
    app.mainloop()
