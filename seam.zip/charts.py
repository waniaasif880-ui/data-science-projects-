"""
charts.py — Matplotlib visualisations for Seam admin panel.
Two charts: category demand bar + exchange velocity line.
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk

# Seam palette
INK      = "#120d0c"
PAPER    = "#f8f4f0"
WARM     = "#f1e8e1"
ROSE     = "#a85c6e"
ROSE2    = "#c97a8a"
PETAL    = "#e8c8cf"
STONE    = "#8c8079"
CREAM    = "#fbf7f4"


def _style_axes(ax, bg=CREAM):
    ax.set_facecolor(bg)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(PETAL)
    ax.spines["bottom"].set_color(PETAL)
    ax.tick_params(colors=STONE, labelsize=8)
    ax.yaxis.label.set_color(STONE)
    ax.xaxis.label.set_color(STONE)
    ax.title.set_color(INK)


def make_category_chart(stats, parent_frame):
    """Bar chart: listings vs completions per category."""
    by_cat = stats["by_category"]
    if not by_cat:
        return None

    cats       = [r["category"] for r in by_cat]
    totals     = [r["total"] for r in by_cat]
    completed  = [r["completed"] for r in by_cat]
    available  = [r["available"] for r in by_cat]

    fig = Figure(figsize=(6, 3.2), facecolor=CREAM, dpi=96)
    ax  = fig.add_subplot(111)
    _style_axes(ax)

    x = range(len(cats))
    w = 0.28

    ax.bar([i - w for i in x], totals,    width=w, color=PETAL,  label="Total listed",  zorder=2)
    ax.bar([i      for i in x], available, width=w, color=ROSE2,  label="Still available", zorder=2)
    ax.bar([i + w for i in x], completed, width=w, color=ROSE,   label="Completed",     zorder=2)

    ax.set_xticks(list(x))
    ax.set_xticklabels(cats, fontsize=8)
    ax.set_ylabel("Listings", fontsize=8)
    ax.set_title("Category Demand", fontsize=10, fontweight="bold", pad=10)
    ax.yaxis.set_major_locator(plt.MaxNLocator(integer=True))
    ax.grid(axis="y", color=WARM, linewidth=0.6, zorder=1)

    legend = ax.legend(
        fontsize=7, frameon=True,
        facecolor=CREAM, edgecolor=PETAL,
        labelcolor=STONE
    )

    fig.tight_layout(pad=1.4)

    canvas = FigureCanvasTkAgg(fig, master=parent_frame)
    canvas.draw()
    return canvas


def make_velocity_chart(stats, parent_frame):
    """Horizontal bar: avg days from listing to pickup per category."""
    velocity = [v for v in stats["velocity"] if v["avg_days"] is not None]
    if not velocity:
        return None

    cats = [v["category"] for v in velocity]
    days = [round(v["avg_days"], 1) for v in velocity]

    fig = Figure(figsize=(6, 2.8), facecolor=CREAM, dpi=96)
    ax  = fig.add_subplot(111)
    _style_axes(ax)

    colors = [ROSE if d <= 3 else ROSE2 if d <= 7 else PETAL for d in days]
    bars = ax.barh(cats, days, color=colors, height=0.5, zorder=2)

    for bar, d in zip(bars, days):
        ax.text(
            bar.get_width() + 0.1, bar.get_y() + bar.get_height() / 2,
            f"{d}d", va="center", fontsize=8, color=STONE
        )

    ax.set_xlabel("Avg days to pickup", fontsize=8)
    ax.set_title("Exchange Velocity", fontsize=10, fontweight="bold", pad=10)
    ax.grid(axis="x", color=WARM, linewidth=0.6, zorder=1)
    ax.invert_yaxis()

    fast  = mpatches.Patch(color=ROSE,  label="≤ 3 days")
    mid   = mpatches.Patch(color=ROSE2, label="4–7 days")
    slow  = mpatches.Patch(color=PETAL, label="> 7 days")
    ax.legend(handles=[fast, mid, slow], fontsize=7, frameon=True,
              facecolor=CREAM, edgecolor=PETAL, labelcolor=STONE)

    fig.tight_layout(pad=1.4)

    canvas = FigureCanvasTkAgg(fig, master=parent_frame)
    canvas.draw()
    return canvas
