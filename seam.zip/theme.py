"""
theme.py — Seam colour tokens, font helpers, and styled widget factories.
All Tkinter widgets in the app are built through these helpers so that
the visual identity stays consistent and is easy to change in one place.
"""

import tkinter as tk
from tkinter import ttk

# ── Palette ──────────────────────────────────────────────────────────────────
INK    = "#120d0c"
INK2   = "#1c1412"
PAPER  = "#f8f4f0"
WARM   = "#f1e8e1"
ROSE   = "#a85c6e"
ROSE2  = "#c97a8a"
PETAL  = "#e8c8cf"
STONE  = "#8c8079"
WHITE  = "#ffffff"
CREAM  = "#fbf7f4"

# Status colours
STATUS_COLORS = {
    "available": ("#2d6a4f", "#d8f3dc"),   # green fg / bg
    "claimed":   ("#7b5e00", "#fff3cd"),   # amber
    "completed": (STONE,     WARM),        # muted
}

CATEGORIES = ["Clothing", "Books & Notes", "Electronics & Gear", "Open"]
CONDITIONS  = ["New", "Good", "Fair", "Worn"]
LOCATIONS   = [
    "Main Cafeteria Info Desk",
    "Library Help Desk",
    "Library Entrance Shelf",
    "Study Room 3, Library",
    "Block C Lab Locker",
    "Engineering Block B",
    "CS Department Pigeonholes",
    "Maths Dept Reception",
    "Architecture Studio",
    "IT Help Desk",
    "Electronics Lab Technician",
    "Girls Hostel Gate",
    "Hostel Block A, Room 110",
    "Hostel Block B Exit",
    "Main Gate Reception",
    "Student Affairs Office",
    "Masjid Entrance",
    "Other (specify in description)",
]

ADMIN_PASSWORD = "seam2024"


# ── Font helpers ──────────────────────────────────────────────────────────────
def F(size=12, weight="normal", slant="roman"):
    return ("Georgia", size, weight, slant)

def Fsans(size=11, weight="normal"):
    return ("Helvetica", size, weight)


# ── Styled widget factories ───────────────────────────────────────────────────

def label(parent, text, size=11, weight="normal", color=INK, bg=PAPER, **kw):
    return tk.Label(parent, text=text, font=Fsans(size, weight),
                    fg=color, bg=bg, **kw)


def heading(parent, text, size=16, color=INK, bg=PAPER, italic=False):
    slant = "italic" if italic else "roman"
    return tk.Label(parent, text=text, font=F(size, "normal", slant),
                    fg=color, bg=bg)


def body(parent, text, size=10, color=STONE, bg=PAPER, wrap=400, **kw):
    return tk.Label(parent, text=text, font=Fsans(size),
                    fg=color, bg=bg, wraplength=wrap, justify="left", **kw)


def entry(parent, textvariable=None, width=32, **kw):
    e = tk.Entry(parent, textvariable=textvariable, width=width,
                 font=Fsans(11), fg=INK, bg=WHITE,
                 relief="flat", bd=0,
                 highlightthickness=1,
                 highlightbackground=PETAL,
                 highlightcolor=ROSE,
                 insertbackground=INK,
                 **kw)
    return e


def textarea(parent, height=4, width=38, **kw):
    t = tk.Text(parent, height=height, width=width,
                font=Fsans(10), fg=INK, bg=WHITE,
                relief="flat", bd=0,
                highlightthickness=1,
                highlightbackground=PETAL,
                highlightcolor=ROSE,
                insertbackground=INK,
                wrap="word",
                **kw)
    return t


def combo(parent, values, textvariable=None, width=30, **kw):
    style = ttk.Style()
    style.theme_use("clam")
    style.configure("Seam.TCombobox",
                    fieldbackground=WHITE,
                    background=WHITE,
                    foreground=INK,
                    arrowcolor=ROSE,
                    bordercolor=PETAL,
                    lightcolor=PETAL,
                    darkcolor=PETAL,
                    selectbackground=PETAL,
                    selectforeground=INK,
                    font=("Helvetica", 11))
    c = ttk.Combobox(parent, values=values, textvariable=textvariable,
                     width=width, state="readonly", style="Seam.TCombobox", **kw)
    return c


def btn(parent, text, command=None, primary=True, small=False, **kw):
    size = 9 if small else 11
    bg   = ROSE   if primary else CREAM
    fg   = WHITE  if primary else INK
    abg  = ROSE2  if primary else WARM
    b = tk.Button(parent, text=text, command=command,
                  font=Fsans(size, "normal"),
                  fg=fg, bg=bg,
                  activeforeground=fg, activebackground=abg,
                  relief="flat", bd=0,
                  padx=16 if not small else 10,
                  pady=8  if not small else 4,
                  cursor="hand2",
                  **kw)
    return b


def divider(parent, bg=PETAL, height=1, pady=0):
    f = tk.Frame(parent, bg=bg, height=height)
    f.pack(fill="x", pady=pady)
    return f


def status_badge(parent, status, bg=PAPER):
    fg_col, bg_col = STATUS_COLORS.get(status, (STONE, WARM))
    return tk.Label(parent, text=status.upper(),
                    font=Fsans(8, "bold"),
                    fg=fg_col, bg=bg_col,
                    padx=6, pady=2)


def scrollable_frame(parent, bg=PAPER):
    """Returns (outer_frame, inner_frame, canvas) — pack/grid outer_frame."""
    outer = tk.Frame(parent, bg=bg)
    canvas = tk.Canvas(outer, bg=bg, highlightthickness=0)
    scrollbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
    inner = tk.Frame(canvas, bg=bg)

    inner.bind("<Configure>",
               lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=inner, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    scrollbar.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)

    def _on_mousewheel(e):
        canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")
    canvas.bind_all("<MouseWheel>", _on_mousewheel)

    return outer, inner, canvas


def card(parent, bg=CREAM, padx=16, pady=12, relief="flat", bd=1):
    f = tk.Frame(parent, bg=bg, relief=relief, bd=bd,
                 highlightthickness=1, highlightbackground=PETAL)
    return f
