# Seam — Campus Goods Exchange

A zero-cost campus goods exchange desktop app built in pure Python.  
One student's surplus becomes another's necessity — no money, no awkward transactions.

---

## Quick Start

**Requirements:** Python 3.8+ (Tkinter and SQLite3 are included in the standard library)

```bash
# Install the only external dependency (charts)
pip install matplotlib

# Run
python app.py
```

That's it. No server, no internet connection, no accounts needed.

---

## How It Works

### For Students (Browse tab)
1. **Browse** available listings — filter by category or search by keyword
2. **Post** an item you want to give away (30 seconds)
3. **Claim** an item → you get a 6-character pickup code
4. Show the code to the giver when you collect → exchange complete

### For Admins (Admin tab)
- Password: `seam2024`
- View demand dashboard: total listings, available, claimed, completed
- Category demand bar chart
- Exchange velocity chart (avg days from listing → pickup)
- Full listings table with the ability to cancel claims or delete listings

### Confirm tab
- Anyone can enter a pickup code to mark an exchange as complete
- Useful for the giver to confirm after handoff

---

## Project Structure

```
seam/
├── app.py        — Main Tkinter application (all views)
├── database.py   — SQLite schema, all DB operations, seed data
├── charts.py     — Matplotlib visualisations (category demand + velocity)
├── theme.py      — Colour tokens, font helpers, styled widget factories
├── README.md     — This file
└── seam.db       — Created automatically on first run
```

---

## Tech Stack

| Library    | Role                              |
|------------|-----------------------------------|
| Python 3.x | Language                          |
| SQLite3    | Local database (stdlib)           |
| Tkinter    | Desktop GUI (stdlib)              |
| Matplotlib | Admin dashboard charts            |
| secrets    | Cryptographically random codes    |
| datetime   | Timestamps, velocity calculations |

---

## Features

- **Pickup Code Handoff** — 6-char alphanumeric code, confirmed by both parties
- **Category filtering** — Clothing / Books & Notes / Electronics & Gear / Open
- **Demand Dashboard** — Admin-only view with live stats
- **Exchange velocity** — avg days from listing to pickup per category
- **Fully offline** — all data lives in `seam.db`, nothing leaves the machine
- **18 sample listings** seeded automatically on first run

---

## Extending the Project

Ideas for further development:
- Add user accounts with a simple login (hashed passwords in SQLite)
- Email/SMS notification when an item is claimed (smtplib)
- Export data to CSV for reporting
- Tkinter search filter with debounce
- Hostel-specific location filtering

---

*Built by Wania — Semester Project, Campus Sustainability domain*
